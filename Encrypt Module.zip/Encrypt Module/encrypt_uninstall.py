import os
os.remove("/Library/Frameworks/Python.framework/Versions/3.6/lib/python3.6/encrypt.py")
print("Module Uninstalled")
